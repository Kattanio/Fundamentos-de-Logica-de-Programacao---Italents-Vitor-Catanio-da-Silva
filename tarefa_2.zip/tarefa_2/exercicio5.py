num1 = float(input("Digite o primeiro número: "))

num2 = float(input("Digite o segundo número: "))

if num1 == num2:
    print("Os números são iguais")
else:
    maior_numero = max(num1, num2)
    print(f"O maior número é: {maior_numero}")
