print("-" * 14)
print("Tabuada do 8")
print("-" * 14)

for i in range(1, 11):
    resultado = 8 * i

    print(f" 8 x {i} = {resultado}")

print("-" * 14)  
