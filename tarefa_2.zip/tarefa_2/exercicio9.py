for num in range(1, 11):

    print("-" * 14)
    print(f"Tabuada do {num}:")
    print("-" * 14)
    
    for i in range(1, 11):
        resultado = num * i

        print(f"{num} x {i} = {resultado}")
