import random

numero_bot = random.randint(0, 10)

adivinhar = int(input("Tente adivinhar o número entre 0 e 10: "))


if adivinhar == numero_bot:
    print("Parabéns! Você acertou!")

else:
    print(f"Você errou. O número que o Bot escolheu era {numero_bot}.")
