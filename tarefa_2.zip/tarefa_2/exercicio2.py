numero = int(input("Digite um número aleatório: "))

if numero % 2 == 0:
    print("O número escolhido é par!")

else:
    print("O número escolhido é ímpar!")
