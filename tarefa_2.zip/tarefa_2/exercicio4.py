valor = float(input("Digite um valor aleatório: "))

if valor > 0:
    print("O valor é positivo")

elif valor < 0:
    print("O valor é negativo")
    
else:
    print("Valor não conhecido. O valor 0 não pode ser reconhecido0.")
