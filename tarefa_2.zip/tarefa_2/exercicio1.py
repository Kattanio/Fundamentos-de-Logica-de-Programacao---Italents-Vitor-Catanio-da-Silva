valor_moeda = {
    'USD': 5.20,
    'EUR': 6.10,
    'GBP': 7.80,
    'CAD': 4.00,
    'ARS': 0.052,
    'CLP': 0.0062
}


valor_em_reais = float(input("Digite o valor do produto em reais (R$): "))

for moeda, valor_moeda in valor_moeda.items():
    valor_convertido = valor_em_reais / valor_moeda
    
    print(f"{moeda} {valor_convertido:.2f}")
